import streamlit as st
import pdfplumber
import json
import os
import re
import uuid
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ============================================================
# CONFIG
# ============================================================
st.set_page_config(page_title="ID'EES INTERIM - IA RH", layout="wide")

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

AGENCES = [
    "ID'EES ALENÇON",
    "ID'EES AVRANCHES",
    "ID'EES DINAN",
    "ID'EES HONFLEUR",
    "ID'EES LE MANS",
    "ID'EES RENNES",
    "ID'EES SAINT-MALO",
]

# Liste de mots vides français (bien plus complète que l'originale)
FRENCH_STOPWORDS = [
    "alors", "au", "aucun", "aucune", "aujourd", "aujourd'hui", "aussi", "autre", "autres",
    "avant", "avec", "avoir", "bon", "car", "ce", "cela", "ces", "cet", "cette", "ceux",
    "chaque", "ci", "comme", "comment", "dans", "de", "des", "du", "dedans", "dehors",
    "depuis", "devrait", "doit", "donc", "dos", "droite", "début", "elle", "elles", "en",
    "encore", "essai", "est", "et", "eu", "fait", "faites", "fois", "font", "hors", "ici",
    "il", "ils", "je", "juste", "la", "le", "les", "leur", "leurs", "là", "ma", "maintenant",
    "mais", "mes", "mine", "moins", "mon", "mot", "même", "mêmes", "ni", "nommés", "notre",
    "nos", "nous", "nouveau", "nouveaux", "ou", "où", "par", "parce", "parole", "pas",
    "personnes", "peut", "peu", "peuvent", "pièce", "plupart", "plus", "pour", "pourquoi",
    "quand", "que", "quel", "quelle", "quelles", "quels", "qui", "quoi", "sa", "sans", "se",
    "ses", "seulement", "si", "sien", "son", "sont", "sous", "soyez", "sujet", "sur", "ta",
    "tandis", "tant", "te", "tellement", "tels", "tes", "toi", "ton", "tous", "tout", "toute",
    "toutes", "tres", "trop", "très", "tu", "un", "une", "valeur", "voie", "voient", "vont",
    "votre", "vos", "vous", "vu", "ça", "étaient", "état", "étions", "été", "être", "à",
    "d", "l", "s", "n", "c", "j", "qu", "cettes", "y", "ceci", "celui", "celle", "cependant",
    "certain", "certaine", "certaines", "certains", "chez", "comme", "comment", "concernant",
    "contre", "dès", "davantage", "delà", "derrière", "désormais", "déjà", "devant", "durant",
    "effet", "également", "elle-même", "enfin", "ensuite", "entre", "envers", "environ",
    "etc", "eux", "eux-mêmes", "excepté", "gens", "ici", "jusqu", "jusque", "la", "laquelle",
    "lequel", "lesquelles", "lesquels", "loin", "longtemps", "lors", "lorsque", "lui",
    "lui-même", "malgré", "me", "merci", "moi", "moi-même", "moindres", "monde", "ne",
    "neanmoins", "néanmoins", "non", "notamment", "nôtres", "nul", "on", "onze", "outre",
    "parfois", "parmi", "partout", "pendant", "peut-être", "plutôt", "plusieurs", "possible",
    "pourrais", "pourrait", "pouvait", "prealable", "préalable", "près", "proche", "puis",
    "puisque", "quant", "quelconque", "quelqu'un", "quelque", "quelques", "quiconque",
    "quoique", "sait", "sauf", "sein", "selon", "sera", "seront", "seul", "seule", "sinon",
    "soi", "soi-même", "soit", "specifique", "spécifique", "suis", "suit", "suivant", "surtout",
    "toi-même", "toujours", "trois", "trouve", "un", "une", "unes", "uns", "va", "vais", "vas",
    "vers", "via", "voici", "voilà", "vous-même", "vous-mêmes", "vôtre", "vôtres", "ô",
]


# ============================================================
# PERSISTANCE (fichiers JSON structurés, avec ID unique)
# ============================================================
def agence_slug(agence: str) -> str:
    return re.sub(r"[^A-Za-z0-9]+", "_", agence).strip("_")


def data_path(kind: str, agence: str) -> str:
    return os.path.join(DATA_DIR, f"{kind}_{agence_slug(agence)}.json")


def load_data(kind: str, agence: str) -> list:
    path = data_path(kind, agence)
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []


def save_data(kind: str, agence: str, data: list) -> None:
    path = data_path(kind, agence)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def add_record(kind: str, agence: str, record: dict) -> dict:
    data = load_data(kind, agence)
    record = dict(record)
    record["id"] = uuid.uuid4().hex[:8]
    record["date"] = datetime.now().strftime("%d/%m/%Y %H:%M")
    data.append(record)
    save_data(kind, agence, data)
    return record


def delete_record(kind: str, agence: str, record_id: str) -> None:
    data = load_data(kind, agence)
    data = [d for d in data if d.get("id") != record_id]
    save_data(kind, agence, data)


# ============================================================
# EXTRACTION PDF
# ============================================================
def extract_text(file) -> str:
    text = ""
    with pdfplumber.open(file) as pdf:
        for page in pdf.pages:
            text += (page.extract_text() or "") + "\n"
    return text.strip()


# ============================================================
# MATCHING (TF-IDF + similarité cosinus)
# ============================================================
def compute_similarity(text_a: str, text_b: str) -> float:
    """Score de compatibilité en % basé sur TF-IDF (unigrammes + bigrammes)."""
    if not text_a.strip() or not text_b.strip():
        return 0.0
    try:
        vectorizer = TfidfVectorizer(
            stop_words=FRENCH_STOPWORDS,
            ngram_range=(1, 2),
            lowercase=True,
            token_pattern=r"(?u)\b[a-zA-ZÀ-ÿ][a-zA-ZÀ-ÿ0-9\-]+\b",
        )
        tfidf = vectorizer.fit_transform([text_a, text_b])
    except ValueError:
        return 0.0
    sim = cosine_similarity(tfidf[0:1], tfidf[1:2])[0][0]
    return round(float(sim) * 100, 1)


def extract_keywords(text: str, top_n: int = 15) -> list:
    """Extrait les termes les plus caractéristiques d'un texte (pour affichage)."""
    if not text.strip():
        return []
    try:
        vectorizer = TfidfVectorizer(
            stop_words=FRENCH_STOPWORDS,
            ngram_range=(1, 2),
            token_pattern=r"(?u)\b[a-zA-ZÀ-ÿ][a-zA-ZÀ-ÿ0-9\-]+\b",
            max_features=top_n,
        )
        vectorizer.fit([text])
        return list(vectorizer.get_feature_names_out())
    except ValueError:
        return []


def score_badge(score: float):
    if score >= 65:
        st.success(f"🟢 {score:.1f} % — Profil recommandé")
    elif score >= 35:
        st.warning(f"🟡 {score:.1f} % — Profil à étudier")
    else:
        st.error(f"🔴 {score:.1f} % — Profil peu adapté")


# ============================================================
# SIDEBAR
# ============================================================
agence = st.sidebar.selectbox("🏢 Agence", AGENCES)

menu = st.sidebar.selectbox(
    "Menu",
    [
        "🏠 Accueil",
        "🟢 Matching CV + Poste",
        "🔵 CV → Postes enregistrés",
        "🔴 Poste → Candidats enregistrés",
        "📁 Base de données",
        "📬 Suivi candidatures",
        "📊 Tableau de bord",
    ],
)

st.sidebar.markdown("---")
st.sidebar.caption(
    "⚠️ Si l'application est hébergée sur Streamlit Community Cloud, "
    "le dossier `data/` est réinitialisé à chaque redéploiement/veille. "
    "Pour une persistance durable, brancher un stockage externe "
    "(base de données, Google Sheets, S3, disque persistant...)."
)

st.title("ID'EES INTERIM — Assistant IA RH")

# ============================================================
# 🏠 ACCUEIL
# ============================================================
if menu == "🏠 Accueil":
    st.subheader("Assistant IA RH ID'EES INTERIM")
    st.write("Gestion des CV, des fiches de poste, matching et suivi des candidatures, par agence.")
    col1, col2, col3 = st.columns(3)
    col1.metric("CV enregistrés", len(load_data("cvs", agence)))
    col2.metric("Postes enregistrés", len(load_data("postes", agence)))
    col3.metric("Candidatures suivies", len(load_data("suivi", agence)))

# ============================================================
# 🟢 MATCHING CV + POSTE (ponctuel)
# ============================================================
elif menu == "🟢 Matching CV + Poste":
    st.subheader("Matching CV / Poste")

    col_a, col_b = st.columns(2)
    with col_a:
        candidat_nom = st.text_input("Nom du candidat")
        cv_file = st.file_uploader("CV (PDF)", type=["pdf"], key="cv_ponctuel")
    with col_b:
        poste_titre = st.text_input("Intitulé du poste")
        job_file = st.file_uploader("Fiche de poste (PDF)", type=["pdf"], key="poste_ponctuel")

    if cv_file and job_file:
        cv_text = extract_text(cv_file)
        job_text = extract_text(job_file)

        if not cv_text or not job_text:
            st.error("Impossible d'extraire le texte d'un des deux PDF (document scanné/image ?).")
        else:
            score = compute_similarity(cv_text, job_text)
            score_badge(score)

            cv_kw = set(extract_keywords(cv_text, top_n=25))
            job_kw = set(extract_keywords(job_text, top_n=25))
            common_kw = cv_kw.intersection(job_kw)

            st.write("**Mots-clés communs :**", ", ".join(sorted(common_kw)) if common_kw else "aucun")

            st.markdown("---")
            if st.button("💾 Enregistrer ce CV et cette fiche de poste dans la base"):
                add_record(
                    "cvs", agence,
                    {
                        "nom": candidat_nom or cv_file.name,
                        "fichier": cv_file.name,
                        "texte": cv_text,
                    },
                )
                add_record(
                    "postes", agence,
                    {
                        "titre": poste_titre or job_file.name,
                        "fichier": job_file.name,
                        "texte": job_text,
                    },
                )
                st.success("CV et poste enregistrés ✔")

# ============================================================
# 🔵 CV → POSTES ENREGISTRÉS
# ============================================================
elif menu == "🔵 CV → Postes enregistrés":
    st.subheader("CV → Postes disponibles")

    candidat_nom = st.text_input("Nom du candidat")
    cv_file = st.file_uploader("CV (PDF)", type=["pdf"], key="cv_vers_postes")

    if cv_file:
        cv_text = extract_text(cv_file)
        postes = load_data("postes", agence)

        if not cv_text:
            st.error("Impossible d'extraire le texte du PDF.")
        elif not postes:
            st.warning("Aucune fiche de poste enregistrée pour cette agence.")
        else:
            resultats = []
            for p in postes:
                score = compute_similarity(cv_text, p.get("texte", ""))
                resultats.append((score, p))
            resultats.sort(key=lambda x: x[0], reverse=True)

            st.write(f"**{len(resultats)} poste(s) comparé(s) — classement par compatibilité :**")
            for score, p in resultats[:10]:
                with st.container(border=True):
                    st.write(f"**{p.get('titre', 'Poste')}**  ({p.get('date', '')})")
                    score_badge(score)

            if st.button("💾 Enregistrer ce CV dans la base"):
                add_record(
                    "cvs", agence,
                    {"nom": candidat_nom or cv_file.name, "fichier": cv_file.name, "texte": cv_text},
                )
                st.success("CV enregistré ✔")

# ============================================================
# 🔴 POSTE → CANDIDATS ENREGISTRÉS
# ============================================================
elif menu == "🔴 Poste → Candidats enregistrés":
    st.subheader("Poste → Candidats disponibles")

    poste_titre = st.text_input("Intitulé du poste")
    job_file = st.file_uploader("Fiche de poste (PDF)", type=["pdf"], key="poste_vers_cvs")

    if job_file:
        job_text = extract_text(job_file)
        cvs = load_data("cvs", agence)

        if not job_text:
            st.error("Impossible d'extraire le texte du PDF.")
        elif not cvs:
            st.warning("Aucun CV enregistré pour cette agence.")
        else:
            resultats = []
            for c in cvs:
                score = compute_similarity(c.get("texte", ""), job_text)
                resultats.append((score, c))
            resultats.sort(key=lambda x: x[0], reverse=True)

            st.write(f"**{len(resultats)} CV comparé(s) — classement par compatibilité :**")
            for score, c in resultats[:10]:
                with st.container(border=True):
                    st.write(f"**{c.get('nom', 'Candidat')}**  ({c.get('date', '')})")
                    score_badge(score)

            if st.button("💾 Enregistrer ce poste dans la base"):
                add_record(
                    "postes", agence,
                    {"titre": poste_titre or job_file.name, "fichier": job_file.name, "texte": job_text},
                )
                st.success("Poste enregistré ✔")

# ============================================================
# 📁 BASE DE DONNÉES (consultation / suppression)
# ============================================================
elif menu == "📁 Base de données":
    st.subheader(f"Base de données — {agence}")

    tab_cv, tab_postes = st.tabs(["CV enregistrés", "Postes enregistrés"])

    with tab_cv:
        cvs = load_data("cvs", agence)
        if not cvs:
            st.info("Aucun CV enregistré.")
        for c in cvs[::-1]:
            with st.container(border=True):
                col1, col2 = st.columns([4, 1])
                col1.write(f"**{c.get('nom')}** — {c.get('fichier')} ({c.get('date')})")
                if col2.button("🗑️ Supprimer", key=f"del_cv_{c['id']}"):
                    delete_record("cvs", agence, c["id"])
                    st.rerun()

    with tab_postes:
        postes = load_data("postes", agence)
        if not postes:
            st.info("Aucun poste enregistré.")
        for p in postes[::-1]:
            with st.container(border=True):
                col1, col2 = st.columns([4, 1])
                col1.write(f"**{p.get('titre')}** — {p.get('fichier')} ({p.get('date')})")
                if col2.button("🗑️ Supprimer", key=f"del_poste_{p['id']}"):
                    delete_record("postes", agence, p["id"])
                    st.rerun()

# ============================================================
# 📬 SUIVI CANDIDATURES
# ============================================================
elif menu == "📬 Suivi candidatures":
    st.subheader("Suivi candidatures")

    nom = st.text_input("Nom candidat")
    poste = st.text_input("Mission")
    statut = st.selectbox("Statut", ["🟡 En attente", "🟢 Mission", "🔴 Refus"])

    if st.button("Enregistrer"):
        if not nom or not poste:
            st.error("Merci de renseigner le nom du candidat et la mission.")
        else:
            add_record("suivi", agence, {"nom": nom, "poste": poste, "statut": statut})
            st.success("Enregistré ✔")

# ============================================================
# 📊 TABLEAU DE BORD
# ============================================================
elif menu == "📊 Tableau de bord":
    st.subheader(f"Tableau de bord — {agence}")

    data = load_data("suivi", agence)

    if not data:
        st.warning("Aucune donnée de suivi pour cette agence.")
    else:
        missions = len([d for d in data if d["statut"] == "🟢 Mission"])
        attente = len([d for d in data if d["statut"] == "🟡 En attente"])
        refus = len([d for d in data if d["statut"] == "🔴 Refus"])

        col1, col2, col3 = st.columns(3)
        col1.metric("Missions", missions)
        col2.metric("En attente", attente)
        col3.metric("Refus", refus)

        st.write("---")

        for d in data[::-1]:
            with st.container(border=True):
                col1, col2 = st.columns([4, 1])
                col1.write(f"**{d['nom']}** → {d['poste']} → {d['statut']}  _(le {d.get('date','')})_")
                if col2.button("🗑️ Supprimer", key=f"del_suivi_{d['id']}"):
                    delete_record("suivi", agence, d["id"])
                    st.rerun()
